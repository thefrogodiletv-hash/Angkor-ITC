# ANGKOR ITC - Computer Accessories Cambodia

One-page online shop (English / Khmer). Orders are sent to Telegram: https://t.me/angkoritc

## Put it on GitHub Pages (free)

**Without git (easiest)**
1. Sign in at github.com and click **New repository**. Name it, for example, `angkoritc`. Choose **Public**. Click **Create repository**.
2. Click **uploading an existing file**, drag in `index.html` and `.nojekyll` (and this README), then **Commit changes**.
3. Go to **Settings -> Pages**. Under **Build and deployment**, set **Source: Deploy from a branch**, **Branch: main**, folder **/ (root)**, then **Save**.
4. Wait 1-2 minutes. Your site is at `https://YOUR-USERNAME.github.io/angkoritc/`

**With git**
```
git init
git add .
git commit -m "ANGKOR ITC shop"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/angkoritc.git
git push -u origin main
```
Then do step 3 above.

## Google sign-in (needs your own Client ID)
1. Google Cloud Console -> APIs & Services -> Credentials -> Create OAuth client ID -> **Web application**.
2. Under **Authorized JavaScript origins** add `https://YOUR-USERNAME.github.io` (no path at the end).
3. In `index.html`, search for `GOOGLE_CLIENT_ID` and paste your ID in place of `YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com`. Commit the change.

Until then, the Google button shows "not set up yet" and customers can still order through Telegram.

## Login email alerts
Alerts go to the email set in `index.html` (search `formsubmit.co`). The first time, FormSubmit sends a confirmation email to that address: click **Activate**.
Note: in a public repository the email address is visible to anyone who views the code.

## Edit products
Open `index.html`, find `const P=[` and edit the list: name, category, icon, price in USD.
